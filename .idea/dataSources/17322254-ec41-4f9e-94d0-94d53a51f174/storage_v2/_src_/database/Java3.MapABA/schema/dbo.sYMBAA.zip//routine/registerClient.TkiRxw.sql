create proc registerClient
	@name nvarchar(20),	@surname nvarchar(20), @hashpass nvarchar(50), @email nvarchar(30)
as
	insert into Clients values(@name, @surname, @hashpass, @email)
go

